package mf00589_project_com1028;

public class Audio extends MusicFile{
	
	private int audioId=0;
	private String audioLink=null;

	public Audio(int audioId, String audiolink,String artistName, int musicId, String musicGroup, String genre) throws NullPointerException{
		super(artistName, musicId, musicGroup, genre);
		//Illegal argument exception if fields have no value 
		if(audioId==0||audiolink==null){
			throw new NullPointerException("Fields cannot be null");
		}else {
		
		this.audioId=audioId;
		this.audioLink=audiolink;
		}
		
	}

	public int getAudioId() {
		return this.audioId;
	}

	public String getAudioLink() {
		return this.audioLink;
	}
	

}
