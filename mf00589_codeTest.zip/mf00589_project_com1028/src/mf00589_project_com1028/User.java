/**
 * 
 */
package mf00589_project_com1028;

/**
 * @author Ferna
 *
 */
public class User {
	private String Username = null;
	private String Password = null;

	public User(String Username, String Password) throws NullPointerException {
		if(Username==null||Password==null){
			throw new NullPointerException("Fields cannot be null");
		}else {
		this.Username = Username;
		this.Password = Password;
		}
	}

	public String getUsername() {
		return this.Username;
	}

	public String getPassword() {
		return this.Password;
	}

}
