package mf00589_project_com1028;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class UserLogin {

	private JFrame frame;
	private JTextField txtusername;
	private JTextField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					UserLogin  window = new UserLogin ();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserLogin () {
		initialize();
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setBounds(80, 77, 69, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username:");
		lblNewLabel_1.setBounds(80, 16, 77, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtusername = new JTextField();
		txtusername.setBounds(158, 13, 168, 26);
		frame.getContentPane().add(txtusername);
		txtusername.setColumns(10);
		
		txtpassword = new JTextField();
		txtpassword.setBounds(158, 74, 168, 26);
		frame.getContentPane().add(txtpassword);
		txtpassword.setColumns(10);
		
		
		SystemManager a1= new SystemManager();
		MusicLibrary m1= new MusicLibrary();
		CD cd1 = new CD(2,56,"Adam",2,"upbeat","pop");
		User admin = new User("mf00589","mf00589");
		
		JButton btnLogin = new JButton("Login");
		
	    btnLogin.addActionListener(new ActionListener() {
	    	@Override
			public void actionPerformed(ActionEvent e) {
	    		String username= txtusername.getText();
	    		String password = txtpassword.getText();
	    		User u1= new User(username,password);
	    		
	    		if(a1.userLogin(u1)) {
	    			txtusername.setText(null);
	    			txtpassword.setText(null);
	    			System.out.println("login successfull");
	    			JOptionPane.showMessageDialog(null, "Login Details Valid", "Login successfull",JOptionPane.INFORMATION_MESSAGE);
	    			UserLibrarywindow w1= new UserLibrarywindow();
	    			UserLibrarywindow.newScreen2();
	    			
	    		}
	    		else {
	    			JOptionPane.showMessageDialog(null, "Invlaid Login Details", "Login Error",JOptionPane.ERROR_MESSAGE);
	    			txtusername.setText(null);
	    			txtpassword.setText(null);
	    		}
	    		a1.closeConnection();
	    	}
	    	
	    });
		btnLogin.setBounds(34, 136, 115, 29);
		frame.getContentPane().add(btnLogin);
		
		
		JButton btnRegister = new JButton("Register");
		
		btnRegister.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				RegisterUser t2= new RegisterUser();
				RegisterUser.newScreen();
			
				
			}
			
		});
		btnRegister.setBounds(168, 136, 115, 29);
		frame.getContentPane().add(btnRegister);
		
		JButton btnExit = new JButton("Clear");
		btnExit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				txtusername.setText(null);
				txtusername.setText(null);
				
			}
		});
		btnExit.setBounds(298, 136, 115, 29);
		frame.getContentPane().add(btnExit);
		
		
		/**JButton txtremove = new JButton("remove");
		
	txtremove.addActionListener(new ActionListener() {
		CD cd1 = new CD(2,56,"Adam",2,"upbeat","pop");
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			m1.removeMusic(cd1,admin);
		}
	});
		txtremove.setBounds(158, 180, 115, 29);
		frame.getContentPane().add(txtremove);**/
	}
}
