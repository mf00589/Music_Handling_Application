package mf00589_project_com1028;


public class CD extends MusicFile {
	private int cdId = 0;
	private int storageSize = 0;
	public CD(int cdId, int storageSize, String artistName, int musicId, String musicGroup, String genre){
		super(artistName, musicId, musicGroup, genre);
		this.cdId = cdId;
		this.storageSize = storageSize;
		

	}

	public int getCdId() {
		return this.cdId;
	}

	public int getStorageSize() {
		return this.storageSize;
	}

}
