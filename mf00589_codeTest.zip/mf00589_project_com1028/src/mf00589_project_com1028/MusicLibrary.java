package mf00589_project_com1028;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MusicLibrary {

	private Statement statement;
	private Connection connect;

	public MusicLibrary() {
		super();

		this.connect = null;
		this.statement = null;
		this.openConnection();
	}

	/** This method opens the connection to the database **/
	private void openConnection() {
		try {
			// recreate the connection if needed
			if (this.connect == null || this.connect.isClosed()) {
				// change the DB Path
				//
				this.connect = DriverManager
						.getConnection("jdbc:hsqldb:file:db_data/myDBfilestore;ifexists=true;shutdown=true", "SA", "");
			}
			// recreate the statement if needed
			if (this.statement == null || this.statement.isClosed()) {
				this.statement = this.connect.createStatement();
			}

		} catch (SQLException e) {
			System.out.println("ERROR - Failed to create a connection to the database");
			throw new RuntimeException(e);
		}

	}

	public void closeConnection() {

		try {

			if (this.statement != null) {
				this.statement.close();
			}
			if (this.connect != null) {
				this.connect.close();
			}
			System.out.println("Closed the connection to the database");
		} catch (Exception e) {
			System.out.print("ERROR-Failed to close the connection to the database");
			throw new RuntimeException(e);
		}
	}
      /**Adds a CD music file to the music library**/
	public void addMusicCD(CD file) throws IllegalArgumentException {
		if(file==null) {
			throw new IllegalArgumentException("Enter file details");
		}
		try {
			PreparedStatement preparedStatement = this.connect.prepareStatement(
					"INSERT INTO musicfile (musicid, genre, artistname, songname) VALUES (?, ?, ?, ?)");

			preparedStatement.setInt(1, file.getMusicId());
			preparedStatement.setString(2, file.getGenre());
			preparedStatement.setString(3, file.getArtistName());
			preparedStatement.setString(4, file.getSongName());

			preparedStatement.executeUpdate();

			PreparedStatement preparedStatement2 = this.connect
					.prepareStatement("INSERT INTO cd (cdid, storagesize) VALUES (?, ?)");

			preparedStatement2.setInt(1, file.getCdId());
			preparedStatement2.setInt(2, file.getStorageSize());

			preparedStatement2.executeUpdate();
		} catch (SQLException e) {
			System.out.println("cannot add musicfile");
			throw new RuntimeException(e);
		}
	}
	 /**Removes a CD music file to the music library**/
	public void removeMusic(CD file, User admin) {
		String sql = "DELETE FROM cd WHERE cdid = ?";
		String sql2 = "DELETE FROM musicfile WHERE musicid = ?";
		if (admin.getUsername() == "mf00589") {
			try {

				PreparedStatement preparedStatement = this.connect.prepareStatement(sql);
				preparedStatement.setInt(1, file.getCdId());
				preparedStatement.executeUpdate();

			}

			catch (SQLException e) {
				System.out.println("cannot remove musicfile");
				throw new RuntimeException(e);
			}
			try {
				PreparedStatement preparedStatment2 = this.connect.prepareStatement(sql2);
				preparedStatment2.setInt(1, file.getCdId());
				preparedStatment2.executeUpdate();
				System.out.println("successfull");
			} catch (SQLException e) {
				System.out.println("cannot remove musicfile");
				throw new RuntimeException(e);
			}
		}
	}
	 /**Adds a audio music file to the music library**/
	public void removeAudio(Audio file, User admin) {
		String sql = "DELETE FROM audio WHERE audioid = ?";
		String sql2 = "DELETE FROM musicfile WHERE musicid = ?";
		if (admin.getUsername().equals("mf00589")) {
			try {

				PreparedStatement preparedStatement = this.connect.prepareStatement(sql);
				preparedStatement.setInt(1, file.getAudioId());
				preparedStatement.executeUpdate();

			}

			catch (SQLException e) {
				System.out.println("cannot remove musicfile");
				throw new RuntimeException(e);
			}
			try {
				PreparedStatement preparedStatment2 = this.connect.prepareStatement(sql2);
				preparedStatment2.setInt(1, file.getAudioId());
				preparedStatment2.executeUpdate();
				System.out.println("successfull");

			} catch (SQLException e) {
				System.out.println("cannot remove musicfile");
				throw new RuntimeException(e);
			}
		}

	}
	 /**Adds a AudioTape music file to the music library**/

	public void removeAudioTape(AudioTape file, User admin) {
		if (admin.getUsername().equals("mf00589")) {
			String sql = "DELETE FROM audiotape WHERE tapeid = ?";
			String sql2 = "DELETE FROM musicfile WHERE musicid = ?";
			try {

				PreparedStatement preparedStatement = this.connect.prepareStatement(sql);
				preparedStatement.setInt(1, file.getTapeId());
				preparedStatement.executeUpdate();

			}

			catch (SQLException e) {
				System.out.println("cannot remove musicfile");
				throw new RuntimeException(e);
			}
			try {
				PreparedStatement preparedStatment2 = this.connect.prepareStatement(sql2);
				preparedStatment2.setInt(1, file.getTapeId());
				preparedStatment2.executeUpdate();
				System.out.println("successfull");
			}

			catch (SQLException e) {
				System.out.println("cannot remove musicfile");
				throw new RuntimeException(e);
			}
		}

	}
	 /**Adds a audio music file to the music library**/
	public void addMusicAudio(Audio file) throws IllegalArgumentException{
		if(file==null) {
			throw new IllegalArgumentException("Enter file details");
		}
		try {
			PreparedStatement preparedStatement = this.connect.prepareStatement(
					"INSERT INTO musicfile (musicid, genre, artistname, songname) VALUES (?, ?, ?, ?)");

			preparedStatement.setInt(1, file.getMusicId());
			preparedStatement.setString(2, file.getGenre());
			preparedStatement.setString(3, file.getArtistName());
			preparedStatement.setString(4, file.getSongName());

			preparedStatement.executeUpdate();

			PreparedStatement preparedStatement2 = this.connect
					.prepareStatement("INSERT INTO audio (audioid, link) VALUES (?, ?)");

			preparedStatement2.setInt(1, file.getAudioId());
			preparedStatement2.setString(2, file.getAudioLink());

			preparedStatement2.executeUpdate();
		} catch (SQLException e) {
			System.out.println("cannot add musicfile");
			throw new RuntimeException(e);
		}
	}
	 /**Adds a AudioTape music file to the music library**/

	public void addMusicTape(AudioTape file)throws IllegalArgumentException {
		if(file==null) {
			throw new IllegalArgumentException("Enter file details");
		}
		try {
			PreparedStatement preparedStatement = this.connect.prepareStatement(
					"INSERT INTO musicfile (musicid, genre, artistname, songname) VALUES (?, ?, ?, ?)");

			preparedStatement.setInt(1, file.getMusicId());
			preparedStatement.setString(2, file.getGenre());
			preparedStatement.setString(3, file.getArtistName());
			preparedStatement.setString(4, file.getSongName());

			preparedStatement.executeUpdate();

			PreparedStatement preparedStatement2 = this.connect
					.prepareStatement("INSERT INTO audiotape (tapeid, musiclength) VALUES (?, ?)");

			preparedStatement2.setInt(1, file.getTapeId());
			preparedStatement2.setInt(2, file.getMusicTimeLength());

			preparedStatement2.executeUpdate();
		} catch (SQLException e) {
			System.out.println("cannot add musicfile");
			throw new RuntimeException(e);
		}
	}
	 /**Gets all the rows from the music library of different music files**/
	public List<CD> displaymusicLibrary() {
		ArrayList<CD> musicfiles = new ArrayList<CD>();

		try {
			// This is our prepared query, that selects everything from book
			// table
			String query = "SELECT * FROM musicfile";

			// Executes the query and stores the results.
			ResultSet results = this.statement.executeQuery(query);
			int musicid = 0;
			String genre = null;
			int cdid = 0;
			int storagesize = 0;

			while (results.next()) {
				musicid = results.getInt("musicid");
				genre = results.getString("genre");
				String artistName = results.getString("artistname");
				String songname = results.getString("songname");

				musicfiles.add(new CD(cdid, storagesize, artistName, musicid, songname, genre));

			}

		} catch (SQLException e) {
			System.out.println("SQLException happened while retrieving records- abort programmme");
			throw new RuntimeException(e);
		}
		return musicfiles;

	}
	 /**gets all audio file links from the database so music can be played**/
	public List<Audio> displayaudio() {
		ArrayList<Audio> musicfiles = new ArrayList<Audio>();
		String query = "SELECT * FROM audio";
		int audioid = 0;
		String link = "";
		String artistName = null;
		int musicid = 0;
		String songname = null;
		String genre = null;

		try {
			ResultSet results = this.statement.executeQuery(query);

			while (results.next()) {
				audioid = results.getInt("audioid");
				link = results.getString("link");
				musicfiles.add(new Audio(audioid, link, artistName, musicid, songname, genre));

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return musicfiles;

	}
	 /**Displays all the audio file links through the use of a iterator **/
	public void showLinks() {
		List<Audio> link = displayaudio();
		Iterator<Audio> iter = link.iterator();

		Audio file;
		while (iter.hasNext()) {
			file = iter.next();
			System.out.println("---- " + file.getAudioId() + " ----");
			System.out.println("Link " + file.getAudioLink());

		}

	}
	 /**Displays all the music files within the library using a iterator **/
	public void showAllFiles() {
		List<CD> mfile = displaymusicLibrary();
		Iterator<CD> iter = mfile.iterator();

		// While there are still results..

		CD file;
		while (iter.hasNext()) {
			file = iter.next();
			System.out.println("---- " + file.getMusicId() + " ----");
			System.out.println("GENRE: " + file.getGenre());
			System.out.println("ARTIST NAME: " + file.getArtistName());
			System.out.println("SONG TITLE: " + file.getSongName() + "\n");

		}
	}
/**checks if a music file is present within the music library**/
	public boolean searchfile(int searchMusicid) throws IllegalArgumentException {
		if(searchMusicid==0) {
			throw new IllegalArgumentException("Enter Valid music id");
		}

		String query = "SELECT * from musicfile";

		ResultSet r1 = null;
		try {
			r1 = this.statement.executeQuery(query);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		try {
			while (r1.next()) {
				if (searchMusicid == r1.getInt("musicid")) {
					return true;
				}

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return false;
	}
}

	


