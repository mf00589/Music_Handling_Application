package mf00589_project_com1028;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class RegisterUser {

	private JFrame frame;
	private JTextField txtUsername;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					RegisterUser window = new RegisterUser();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegisterUser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblRegisterUser = new JLabel("Register User");
		lblRegisterUser.setBounds(156, 16, 257, 20);
		frame.getContentPane().add(lblRegisterUser);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(47, 63, 76, 20);
		frame.getContentPane().add(lblUsername);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(124, 60, 146, 26);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(47, 115, 69, 20);
		frame.getContentPane().add(lblPassword);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(124, 112, 146, 26);
		frame.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.addActionListener(new ActionListener(){
SystemManager a1= new SystemManager();

			@Override
			public void actionPerformed(ActionEvent e) {
				String username= txtUsername.getText();
				String password= txtUsername.getText();
				User u1= new User(username,password);
				
				if(a1.registerUser(u1)) {
					JOptionPane.showMessageDialog(null, "Registration Details Valid", "Registration successfull",JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
			
		});
		btnSignUp.setBounds(125, 179, 115, 29);
		frame.getContentPane().add(btnSignUp);
	}

}
