package mf00589_project_com1028;

public class AudioTape extends MusicFile{
	
	private int tapeId=0;
	private int musicTimeLength=0;
	
	public AudioTape(int tapeId,int musicTimeLength,String artistName, int musicId, String musicGroup, String genre)throws NullPointerException {
		super(artistName, musicId, musicGroup, genre);
		//Illegal argument exception if fields have no value 
		if(tapeId==0||musicTimeLength==0){
			throw new NullPointerException("Fields cannot be null");
		}else {
		this.tapeId=tapeId;
		this.musicTimeLength=musicTimeLength;
		}
		
	}


	public int getTapeId() {
		return this.tapeId;
	}

	public int getMusicTimeLength() {
		return this.musicTimeLength;
	}
	

}
