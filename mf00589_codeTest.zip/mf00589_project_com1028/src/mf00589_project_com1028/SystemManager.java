package mf00589_project_com1028;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SystemManager {

	private Connection connect;
	private Statement statement;

	public SystemManager() {
		super();

		this.connect = null;
		this.statement = null;
		this.openConnection();

	}
	

	private void openConnection() {
		try {
			// recreate the connection if needed
			if (this.connect == null || this.connect.isClosed()) {
				// The path to the DB file 
				this.connect = DriverManager
						.getConnection("jdbc:hsqldb:file:db_data/myDBfilestore;ifexists=true;shutdown=true", "SA", "");
			}
			// recreate the statement if needed
			if (this.statement == null || this.statement.isClosed()) {
				this.statement = this.connect.createStatement();
			}

		} catch (SQLException e) {
			System.out.println("ERROR - Failed to create a connection to the database");
			throw new RuntimeException(e);
		}

	}

	public void closeConnection() {

		try {

			if (this.statement != null) {
				this.statement.close();
			}
			if (this.connect != null) {
				this.connect.close();
			}
			System.out.println("Closed the connection to the database");
		} catch (Exception e) {
			System.out.print("ERROR-Failed to close the connection to the database");
			throw new RuntimeException(e);
		}
	}
	/**This method registers user onto the system if their username is not already taken**/

	public boolean registerUser(User user) throws NullPointerException {
		//check if the username or password is null
		if(user.getUsername()==null||user.getPassword()==null) {
			throw new NullPointerException("No details entered");
		}
		//queries through the userinfo table to check if the user alrady exists 
		String query = "SELECT * from userinfo";

		ResultSet r1 = null;
		try {
			r1 = this.statement.executeQuery(query);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			while (r1.next()) {
				//compares the inputed username with the usernames within the DB
				if (!user.getUsername().equals(r1.getString("username"))) {
					try {

						// Prepared statements which allows variables to be used within the statements
						PreparedStatement preparedStatement = this.connect
								.prepareStatement("INSERT INTO userinfo (username, password) VALUES (?, ?)");

						preparedStatement.setString(1, user.getUsername());
						preparedStatement.setString(2, user.getPassword());

						// This executes the query.
						preparedStatement.executeUpdate();
						return true;

					} catch (SQLException e) {
						System.out.println("Username is already taken");
						throw new RuntimeException(e);
					}
				}

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return false;
	}
/**This method allows the user to login in the systems only if the user is already registered**/
	public boolean userLogin(User user) {

		String query = "SELECT * from userinfo";

		ResultSet r1 = null;
		try {
			r1 = this.statement.executeQuery(query);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		try {
			//checks if the username is matches the usernames provided within the database.
			while (r1.next()) {
				if (user.getUsername().equals(r1.getString("username"))
						&& user.getPassword().equals(r1.getString("password"))) {
					return true;
				}

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return false;
	}
	

}
