package mf00589_project_com1028;



public abstract class MusicFile {
	private String artistName= null;
	private int musicId=0;
	private String songname=null;
	private String genre = null;
	
	public MusicFile(String artistName,int musicId,String songname, String genre) {
		super();
		this.artistName=artistName;
		this.musicId=musicId;
		this.songname=songname;
		this.genre=genre;
		
		
	}
	
	public String getArtistName() {
		return artistName;
	}

	public int getMusicId() {
		return this.musicId;
	}

	public String getSongName() {
		return this.songname;
	}

	public String getGenre() {
		return genre;
	}
	

}
