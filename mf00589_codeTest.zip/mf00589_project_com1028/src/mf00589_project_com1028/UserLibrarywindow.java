package mf00589_project_com1028;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class UserLibrarywindow {

	private JFrame frame;
	
	SystemManager a1= new SystemManager();
	User admin = new User("mf00589","mf00589");
	MusicLibrary m1= new MusicLibrary();
    Audio audio = new Audio(21,"https://www.youtube.com/results?search_query=never+gonna+give+you+up","sam",21,"90's","classic");
    AudioTape tape= new AudioTape(25,15,"tom",25,"80's","top");
    private JTextField txtmusicserch;
    
	/**
	 * Launch the application.
	 */
	public static void newScreen2() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					UserLibrarywindow window = new UserLibrarywindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserLibrarywindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnAddCdFile = new JButton("ADD CD FILE");
		
		btnAddCdFile.addActionListener(new ActionListener(){
			CD cd1 = new CD(2,56,"Adam",2,"upbeat","pop");

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				m1.addMusicCD(cd1);
				
				System.out.println("successfull");	
				
				//	m1.closeConnection();
				
			}
		});
		
		btnAddCdFile.setBounds(15, 56, 135, 29);
		frame.getContentPane().add(btnAddCdFile);
		
		JButton btnAddAudioFile = new JButton("ADD AUDIO FILE");
		
		btnAddAudioFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				m1.addMusicAudio(audio);
				
				System.out.println("successfull");	
				
			//	m1.closeConnection();
			
				
			}
			
		});
		btnAddAudioFile.setBounds(15, 91, 164, 29);
		frame.getContentPane().add(btnAddAudioFile);
		
		JButton btnAddTapeFile = new JButton("ADD TAPE FILE");
		btnAddTapeFile.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				m1.addMusicTape(tape);
              System.out.println("successfull");	
				
				m1.closeConnection();
				
			}});
		btnAddTapeFile.setBounds(15, 127, 164, 29);
		frame.getContentPane().add(btnAddTapeFile);
		
		JLabel lblLibraryManagment = new JLabel("LIBRARY MANAGMENT");
		lblLibraryManagment.setBounds(137, 16, 181, 20);
		frame.getContentPane().add(lblLibraryManagment);
		
		JButton btnRemoveCd = new JButton("REMOVE CD");
		
		btnRemoveCd.addActionListener(new ActionListener() {
			CD cd1 = new CD(2,56,"Adam",2,"upbeat","pop");

			@Override
			public void actionPerformed(ActionEvent e) {
			
			m1.removeMusic(cd1,admin);
			m1.closeConnection();
				
			}});
		btnRemoveCd.setBounds(255, 56, 142, 29);
		frame.getContentPane().add(btnRemoveCd);
		
		JButton btnNewButton = new JButton("REMOVE AUDIO");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
			m1.removeAudio(audio,admin);
			m1.closeConnection();
			}
		});
		btnNewButton.setBounds(255, 91, 158, 29);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnRemoveTape = new JButton("REMOVE TAPE");
		btnRemoveTape.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
		
			m1.removeAudioTape(tape, admin);
			m1.closeConnection();
				
			}});
		btnRemoveTape.setBounds(255, 127, 142, 29);
		frame.getContentPane().add(btnRemoveTape);
		
		JButton btnDisplayFiles = new JButton("Display Files");
		
		btnDisplayFiles.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
			m1.showAllFiles();
			m1.showLinks();
			
		}});
		
		
		
		btnDisplayFiles.setBounds(150, 163, 135, 29);
		frame.getContentPane().add(btnDisplayFiles);
		
		JButton btnSearchMusicId = new JButton("Search Music ID");
		btnSearchMusicId.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				int musicid= Integer.parseInt(txtmusicserch.getText());
				if(m1.searchfile(musicid)) {
					JOptionPane.showMessageDialog(null, "file found", "file exist",JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
			
		});
		btnSearchMusicId.setBounds(15, 199, 150, 29);
		frame.getContentPane().add(btnSearchMusicId);
		
		txtmusicserch = new JTextField();
		txtmusicserch.setBounds(172, 200, 146, 26);
		frame.getContentPane().add(txtmusicserch);
		txtmusicserch.setColumns(10);
	}
}
