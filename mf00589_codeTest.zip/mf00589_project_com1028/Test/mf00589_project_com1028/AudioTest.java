package mf00589_project_com1028;

import static org.junit.Assert.*;

import org.junit.Test;

public class AudioTest {

	@Test
	public void test() {
		Audio a1 = new Audio(123,"testlink","testname",123,"testgroup","testgenre");
		assertEquals(123,a1.getAudioId());
	}

}
