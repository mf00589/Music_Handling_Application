package mf00589_project_com1028;

import static org.junit.Assert.*;

import org.junit.Test;

public class MusicLibraryTest {

	@Test
	public void test() {
		MusicLibrary m1= new MusicLibrary();
		assertEquals(true,m1.searchfile(123));
	}

}
