package mf00589_project_com1028;

import static org.junit.Assert.*;

import org.junit.Test;

public class CDTest {

	@Test
	public void test() {
		CD a1 = new CD(173,53,"testname",123,"testgroup","testgenre");
		assertEquals(173, a1.getCdId());
	}

}
