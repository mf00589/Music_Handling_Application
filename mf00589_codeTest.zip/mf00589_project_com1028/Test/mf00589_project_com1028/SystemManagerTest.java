package mf00589_project_com1028;

import static org.junit.Assert.*;

import org.junit.Test;

public class SystemManagerTest {

	@Test
	public void testUserRegisteration() {
		User a1 = new User("sam","apple");
		SystemManager s1 = new SystemManager();
		assertEquals(true,s1.registerUser(a1));
	}
	
	public void invalidUserRegistrartion() {
		User a1= new User("mf00589","mf00589");
		SystemManager s1 = new SystemManager();
		assertEquals(false,s1.registerUser(a1));
		
	}
	@Test(expected = NullPointerException.class)
    public void noDetailsRegisterd() {
    	SystemManager s1 = new SystemManager();
    	assertEquals(false,s1.registerUser(null));
    
    }
	public void testUserLogin() {
		User a1= new User("mf00589","mf00589");
		SystemManager s1 = new SystemManager();
		assertEquals(true, s1.userLogin(a1));
	
	}
	public void invalidUserLogin() {
		User a1= new User("phill","123");
		SystemManager s1 = new SystemManager();
		assertEquals(false, s1.userLogin(a1));
	
	}

}
