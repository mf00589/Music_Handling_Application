package mf00589_project_com1028;

import static org.junit.Assert.*;

import org.junit.Test;

public class AudioTapeTest {

	@Test
	public void test() {
		AudioTape a1 = new AudioTape(189,12,"testname",123,"testgroup","testgenre");
		assertEquals(189,a1.getTapeId());
	}

}
