package mf00589_project_com1028;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserTest {

	@Test
	public void usercreationtest() {
		User u1= new User("peter","pineapple");
	    assertEquals(u1.getUsername(),"peter");
	}

}
